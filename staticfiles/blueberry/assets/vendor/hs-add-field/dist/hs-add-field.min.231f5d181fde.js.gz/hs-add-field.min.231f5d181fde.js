! function (e, n) {
    "object" == typeof exports && "object" == typeof module ? module.exports = n() : "function" == typeof define && define.amd ? define([], n) : "object" == typeof exports ? exports.HSAddField = n() : e.HSAddField = n()
}(window, function () {
    return d = {
        "./src/js/hs-add-field.js": function (module, __webpack_exports__, __webpack_require__) {
            "use strict";
            eval('__webpack_require__.r(__webpack_exports__);\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return HSAddField; });\nfunction _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }\n\nfunction _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }\n\nfunction _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }\n\n/*\n* HSCounter Plugin\n* @version: 2.0.0 (Mon, 25 Nov 2019)\n* @requires: jQuery v3.0 or later\n* @author: Nimusoft\n* @event-namespace: .HSAddField\n* @license: Nimusoft Libraries ()\n* Copyright 2019 Nimusoft\n*/\nvar HSAddField = /*#__PURE__*/function () {\n  function HSAddField(element, config) {\n    _classCallCheck(this, HSAddField);\n\n    this.element = element;\n    this.defaults = {\n      createTrigger: \'.js-create-field\',\n      deleteTrigger: \'.js-delete-field\',\n      limit: 5,\n      defaultCreated: 1,\n      nameSeparator: \'_\',\n      addedField: function addedField() {},\n      deletedField: function deletedField() {}\n    };\n    this.config = config;\n    this.flags = {\n      name: \'data-name\',\n      "delete": \'data-hs-add-field-delete\'\n    };\n    this.fieldsCount = 0;\n  }\n\n  _createClass(HSAddField, [{\n    key: "init",\n    value: function init() {\n      var _this = this;\n\n      var self = this,\n          element = this.element,\n          dataSettings = $(element).attr(\'data-hs-add-field-options\') ? JSON.parse($(element).attr(\'data-hs-add-field-options\')) : {};\n      this.config = Object.assign({}, this.defaults, this.config, dataSettings);\n      this.fieldsCount = this.config.defaultCreated;\n\n      for (var i = 0; i < this.config.defaultCreated; i++) {\n        this.__addField(this.config);\n      }\n\n      $(this.element).on(\'click\', this.config.createTrigger, function () {\n        _this.__addField(_this.config);\n      });\n      $(this.element).on(\'click\', this.config.deleteTrigger, function (e) {\n        _this.__deleteField(_this.config, $(e.currentTarget).attr(_this.flags["delete"]));\n      });\n    }\n  }, {\n    key: "__addField",\n    value: function __addField(params) {\n      var settings = params;\n\n      if (this.fieldsCount < settings.limit) {\n        var field = $(settings.template).clone().removeAttr(\'id\').css({\n          display: \'\'\n        }).appendTo($(settings.container));\n\n        this.__updateFieldsCount();\n\n        this.__renderName();\n\n        this.__renderKeys();\n\n        this.__toggleCreateButton();\n\n        this.config.addedField();\n      }\n    }\n  }, {\n    key: "__deleteField",\n    value: function __deleteField(params, index) {\n      var settings = params;\n\n      if (this.fieldsCount > 0) {\n        $(settings.container).children()[index].remove();\n\n        this.__updateFieldsCount();\n\n        this.__renderName();\n\n        this.__renderKeys();\n\n        this.__toggleCreateButton();\n\n        this.config.deletedField();\n      }\n    }\n  }, {\n    key: "__renderName",\n    value: function __renderName() {\n      var _this2 = this;\n\n      $(this.config.container).children().each(function (i, el) {\n        var key = i;\n        $(el).find("[".concat(_this2.flags.name, "]")).each(function (i, el) {\n          var name = $(el).attr(_this2.flags.name);\n          $(el).attr(\'name\', name + _this2.config.nameSeparator + key);\n        });\n      });\n    }\n  }, {\n    key: "__renderKeys",\n    value: function __renderKeys() {\n      var _this3 = this;\n\n      $(this.config.container).children().find(this.config.deleteTrigger).each(function (i, el) {\n        $(el).attr(_this3.flags["delete"], i);\n      });\n    }\n  }, {\n    key: "__updateFieldsCount",\n    value: function __updateFieldsCount() {\n      this.fieldsCount = $(this.config.container).children().length;\n    }\n  }, {\n    key: "__toggleCreateButton",\n    value: function __toggleCreateButton() {\n      if (this.fieldsCount === this.config.limit) {\n        $(this.config.createTrigger).fadeOut(0);\n      } else {\n        $(this.config.createTrigger).fadeIn(0);\n      }\n    }\n  }]);\n\n  return HSAddField;\n}();\n\n\n\n//# sourceURL=webpack://HSAddField/./src/js/hs-add-field.js?')
        }
    }, e = {}, f.m = d, f.c = e, f.d = function (e, n, t) {
        f.o(e, n) || Object.defineProperty(e, n, {
            enumerable: !0,
            get: t
        })
    }, f.r = function (e) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, f.t = function (n, e) {
        if (1 & e && (n = f(n)), 8 & e) return n;
        if (4 & e && "object" == typeof n && n && n.__esModule) return n;
        var t = Object.create(null);
        if (f.r(t), Object.defineProperty(t, "default", {
                enumerable: !0,
                value: n
            }), 2 & e && "string" != typeof n)
            for (var i in n) f.d(t, i, function (e) {
                return n[e]
            }.bind(null, i));
        return t
    }, f.n = function (e) {
        var n = e && e.__esModule ? function () {
            return e.default
        } : function () {
            return e
        };
        return f.d(n, "a", n), n
    }, f.o = function (e, n) {
        return Object.prototype.hasOwnProperty.call(e, n)
    }, f.p = "", f(f.s = "./src/js/hs-add-field.js").default;

    function f(n) {
        if (e[n]) return e[n].exports;
        var t = e[n] = {
            i: n,
            l: !1,
            exports: {}
        };
        return d[n].call(t.exports, t, t.exports, f), t.l = !0, t.exports
    }
    var d, e
});