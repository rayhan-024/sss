! function (t, e) {
    "object" == typeof exports && "object" == typeof module ? module.exports = e() : "function" == typeof define && define.amd ? define([], e) : "object" == typeof exports ? exports.HSToggleState = e() : t.HSToggleState = e()
}(window, function () {
    return (d = {
        "./src/js/hs-toggle-state.js": function (module, exports, __webpack_require__) {
            "use strict";
            eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n\tvalue: true\n});\n\nvar _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if (\"value\" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();\n\nfunction _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError(\"Cannot call a class as a function\"); } }\n\n/*\n* HSToggleState Plugin\n* @version: 2.0.0 (Mon, 25 Nov 2019)\n* @requires: jQuery v3.0 or later\n* @author: Nimusoft\n* @event-namespace: .HSToggleState\n* @license: Nimusoft Libraries ()\n* Copyright 2019 Nimusoft\n*/\n\nvar HSToggleState = function () {\n\tfunction HSToggleState(elem, settings) {\n\t\t_classCallCheck(this, HSToggleState);\n\n\t\tthis.elem = elem;\n\t\tthis.defaults = {\n\t\t\ttargetSelector: null,\n\t\t\tslaveSelector: null,\n\n\t\t\tclassMap: {\n\t\t\t\ttoggle: 'toggled'\n\t\t\t}\n\t\t};\n\t\tthis.settings = settings;\n\t}\n\n\t_createClass(HSToggleState, [{\n\t\tkey: 'init',\n\t\tvalue: function init() {\n\t\t\tvar context = this,\n\t\t\t    $el = context.elem,\n\t\t\t    dataSettings = $el.attr('data-hs-toggle-state-options') ? JSON.parse($el.attr('data-hs-toggle-state-options')) : {},\n\t\t\t    options = $.extend(true, context.defaults, dataSettings, context.settings);\n\n\t\t\tcontext._prepareObject($el, options);\n\n\t\t\t$el.on('click', function () {\n\t\t\t\t$el.toggleClass(options.classMap.toggle);\n\n\t\t\t\tif (options.slaveSelector) {\n\t\t\t\t\tif ($el.hasClass(options.classMap.toggle)) {\n\t\t\t\t\t\t$(options.slaveSelector).addClass(options.classMap.toggle);\n\t\t\t\t\t} else {\n\t\t\t\t\t\t$(options.slaveSelector).removeClass(options.classMap.toggle);\n\t\t\t\t\t}\n\t\t\t\t}\n\n\t\t\t\tcontext._checkState($el, options);\n\t\t\t});\n\n\t\t\t$(options.slaveSelector).on('click', function () {\n\t\t\t\t$('[data-hs-toggle-state-slave=\"' + options.slaveSelector + '\"]').removeClass(options.classMap.toggle);\n\t\t\t});\n\t\t}\n\t}, {\n\t\tkey: '_prepareObject',\n\t\tvalue: function _prepareObject(el, params) {\n\t\t\tvar options = params;\n\n\t\t\tel.attr('data-hs-toggle-state-slave', options.slaveSelector);\n\t\t}\n\t}, {\n\t\tkey: '_checkState',\n\t\tvalue: function _checkState(el, params) {\n\t\t\tvar options = params;\n\n\t\t\tif (el.hasClass(options.classMap.toggle)) {\n\t\t\t\t$(options.targetSelector).prop('checked', true);\n\t\t\t} else {\n\t\t\t\t$(options.targetSelector).prop('checked', false);\n\t\t\t}\n\t\t}\n\t}]);\n\n\treturn HSToggleState;\n}();\n\nexports.default = HSToggleState;\n\n//# sourceURL=webpack://HSToggleState/./src/js/hs-toggle-state.js?")
        }
    }, e = {}, f.m = d, f.c = e, f.d = function (t, e, n) {
        f.o(t, e) || Object.defineProperty(t, e, {
            enumerable: !0,
            get: n
        })
    }, f.r = function (t) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(t, "__esModule", {
            value: !0
        })
    }, f.t = function (e, t) {
        if (1 & t && (e = f(e)), 8 & t) return e;
        if (4 & t && "object" == typeof e && e && e.__esModule) return e;
        var n = Object.create(null);
        if (f.r(n), Object.defineProperty(n, "default", {
                enumerable: !0,
                value: e
            }), 2 & t && "string" != typeof e)
            for (var o in e) f.d(n, o, function (t) {
                return e[t]
            }.bind(null, o));
        return n
    }, f.n = function (t) {
        var e = t && t.__esModule ? function () {
            return t.default
        } : function () {
            return t
        };
        return f.d(e, "a", e), e
    }, f.o = function (t, e) {
        return Object.prototype.hasOwnProperty.call(t, e)
    }, f.p = "", f(f.s = "./src/js/hs-toggle-state.js")).default;

    function f(t) {
        if (e[t]) return e[t].exports;
        var n = e[t] = {
            i: t,
            l: !1,
            exports: {}
        };
        return d[t].call(n.exports, n, n.exports, f), n.l = !0, n.exports
    }
    var d, e
});