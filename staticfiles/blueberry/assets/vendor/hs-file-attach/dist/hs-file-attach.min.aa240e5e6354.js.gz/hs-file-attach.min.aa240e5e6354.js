! function (e, t) {
    "object" == typeof exports && "object" == typeof module ? module.exports = t() : "function" == typeof define && define.amd ? define([], t) : "object" == typeof exports ? exports.HSFileAttach = t() : e.HSFileAttach = t()
}(window, function () {
    return d = {
        "./src/js/hs-file-attach.js": function (module, __webpack_exports__, __webpack_require__) {
            "use strict";
            eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"default\", function() { return HSFileAttach; });\nfunction _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError(\"Cannot call a class as a function\"); } }\n\nfunction _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if (\"value\" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }\n\nfunction _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }\n\n/*\n* HSFileAttach Plugin\n* @version: 2.0.0 (Mon, 25 Nov 2019)\n* @requires: jQuery v3.0 or later\n* @author: Nimusoft\n* @event-namespace: .HSFileAttach\n* @license: Nimusoft Libraries ()\n* Copyright 2019 Nimusoft\n*/\nvar HSFileAttach = /*#__PURE__*/function () {\n  function HSFileAttach(elem, settings) {\n    _classCallCheck(this, HSFileAttach);\n\n    this.elem = elem;\n    this.defaults = {\n      textTarget: null,\n      maxFileSize: 1024,\n      // Infinity - off file size detection\n      errorMessage: 'File is too big!',\n      mode: 'simple',\n      targetAttr: null\n    };\n    this.settings = settings;\n  }\n\n  _createClass(HSFileAttach, [{\n    key: \"init\",\n    value: function init() {\n      var context = this,\n          $el = context.elem,\n          dataSettings = $el.attr('data-hs-file-attach-options') ? JSON.parse($el.attr('data-hs-file-attach-options')) : {},\n          options = Object.assign({}, context.defaults, dataSettings, context.settings);\n      var $target = $(options.textTarget);\n      $el.on('change', function () {\n        if ($el.val() === '') {\n          return;\n        }\n\n        if (this.files[0].size > options.maxFileSize * 1024) {\n          alert(options.errorMessage);\n          return;\n        }\n\n        if (options.mode === 'image') {\n          context._image($el, $target, options);\n        } else {\n          context._simple($el, $target);\n        }\n      });\n    }\n  }, {\n    key: \"_simple\",\n    value: function _simple(el, target) {\n      target.text(el.val().replace(/.+[\\\\\\/]/, ''));\n    }\n  }, {\n    key: \"_image\",\n    value: function _image(el, target, settings) {\n      var reader;\n\n      if (el[0].files && el[0].files[0]) {\n        reader = new FileReader();\n\n        reader.onload = function (e) {\n          target.attr(settings.targetAttr, e.target.result);\n        };\n\n        reader.readAsDataURL(el[0].files[0]);\n      }\n    }\n  }]);\n\n  return HSFileAttach;\n}();\n\n\n\n//# sourceURL=webpack://HSFileAttach/./src/js/hs-file-attach.js?")
        }
    }, e = {}, f.m = d, f.c = e, f.d = function (e, t, n) {
        f.o(e, t) || Object.defineProperty(e, t, {
            enumerable: !0,
            get: n
        })
    }, f.r = function (e) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, f.t = function (t, e) {
        if (1 & e && (t = f(t)), 8 & e) return t;
        if (4 & e && "object" == typeof t && t && t.__esModule) return t;
        var n = Object.create(null);
        if (f.r(n), Object.defineProperty(n, "default", {
                enumerable: !0,
                value: t
            }), 2 & e && "string" != typeof t)
            for (var r in t) f.d(n, r, function (e) {
                return t[e]
            }.bind(null, r));
        return n
    }, f.n = function (e) {
        var t = e && e.__esModule ? function () {
            return e.default
        } : function () {
            return e
        };
        return f.d(t, "a", t), t
    }, f.o = function (e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    }, f.p = "", f(f.s = "./src/js/hs-file-attach.js").default;

    function f(t) {
        if (e[t]) return e[t].exports;
        var n = e[t] = {
            i: t,
            l: !1,
            exports: {}
        };
        return d[t].call(n.exports, n, n.exports, f), n.l = !0, n.exports
    }
    var d, e
});